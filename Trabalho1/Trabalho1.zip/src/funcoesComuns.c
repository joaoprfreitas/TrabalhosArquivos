#include <funcoesComuns.h>

