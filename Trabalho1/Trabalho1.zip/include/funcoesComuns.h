#ifndef FUNCOESCOMUNS_H
#define FUNCOESCOMUNS_H



#endif